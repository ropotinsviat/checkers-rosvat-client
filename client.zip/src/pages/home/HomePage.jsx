import { useAuth } from "../../context/AuthContext";
import { useSocketContext } from "../../context/SocketContext";
import { useState } from "react";
import "../../assets/css/home.css";
import CreateRoom from "./CreateRoom";
import JoinRoom from "./JoinRoom";

const HomePage = () => {
  const { socket } = useSocketContext();
  const [mode, setMode] = useState();

  function playOnline() {
    socket.emit("playOnline");
    setMode(1);
  }
  function openCreateRoom() {
    setMode(2);
  }
  function openJoinRoom() {
    setMode(3);
  }

  function createRoom(name, password, timeLimit) {
    socket.emit("createRoom", { name, password, timeLimit }, (callback) => {
      if (callback) setMode(1);
    });
  }
  function joinRoom(name, password) {
    socket.emit("joinRoom", { name, password });
  }

  function cancel() {
    window.location.reload();
  }

  return (
    <>
      <div className="home-wrapper">
        {mode === 1 ? (
          <>
            <div className="ideal-center">
              <div className="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <div>Searching for a player...</div>
              <div className="custom-btn" id="mrg-top">
                <input value="Cancel" type="button" onClick={cancel} />
              </div>
            </div>
          </>
        ) : mode === 2 ? (
          <CreateRoom cancel={cancel} createRoom={createRoom} />
        ) : mode === 3 ? (
          <JoinRoom cancel={cancel} joinRoom={joinRoom} />
        ) : (
          <>
            <div className="play-btn general-btn">
              <input
                type="button"
                value="Play checkers online"
                onClick={playOnline}
              />
            </div>
            <div className="join-create-box">
              <div className="side-btn general-btn">
                <input type="button" value="Join room" onClick={openJoinRoom} />
              </div>
              <div className="side-btn general-btn">
                <input
                  type="button"
                  value="Create room"
                  onClick={openCreateRoom}
                />
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default HomePage;
